import React, { useEffect, useState } from 'react';
import { Bell, X, CalendarClock, Info } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Notificaciones = ({ userData }) => {
  const navigate = useNavigate();
  const [notificaciones, setNotificaciones] = useState([]);

  useEffect(() => {
    if (!userData?.id_usuario) return;
    axios
      .get(`http://localhost:5000/notificaciones/${userData.id_usuario}?no_leidas=true`)
      .then((res) => setNotificaciones(res.data))
      .catch((err) => console.error("Error al obtener notificaciones:", err));
  }, [userData]);

  const marcarComoLeida = (id_notificacion) => {
    axios
      .patch(`http://localhost:5000/notificaciones/${id_notificacion}/leido`)
      .then(() => {
        setNotificaciones((prev) =>
          prev.filter((n) => n.id_notificacion !== id_notificacion)
        );
      });
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-30 z-50">
      <div className="bg-white rounded-2xl shadow-xl w-[90%] md:w-[60%] p-6 max-h-[90vh] flex flex-col">
        {/* Encabezado */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-blue-600 flex items-center space-x-2">
            <Bell className="w-6 h-6 text-blue-500" />
            <span>Notificaciones</span>
          </h2>
          <button
            onClick={() => navigate('..')}
            className="text-gray-500 hover:text-red-500 transition"
            type="button"
            aria-label="Cerrar notificaciones"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contenido */}
        <div className="overflow-y-auto space-y-4 pr-1" style={{ maxHeight: 'calc(90vh - 80px)' }}>
          {notificaciones.length === 0 ? (
            <p className="text-gray-500 text-sm text-center py-4">
              No tienes notificaciones nuevas.
            </p>
          ) : (
            notificaciones.map((noti) => (
              <div
                key={noti.id_notificacion}
                className="bg-white border-l-4 border-blue-500 p-4 rounded-lg shadow hover:bg-blue-50 transition"
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-3">
                    <Info className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="text-sm text-gray-800">{noti.mensaje}</p>
                      <p className="text-xs text-gray-500 flex items-center mt-1">
                        <CalendarClock className="w-3 h-3 mr-1" />
                        {new Date(noti.fecha).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => marcarComoLeida(noti.id_notificacion)}
                    className="text-xs text-blue-600 hover:underline"
                  >
                    Marcar como leída
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Notificaciones;

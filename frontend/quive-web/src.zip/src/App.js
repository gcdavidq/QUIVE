import React from 'react';
import QuiveApp from './components/QuiveApp';

function App() {
  return <QuiveApp />;
}

export default App;
